#include<iostream>
using namespace std;
int main()
{
	int a=10;
	cout<<"Adress of a: "<<&a<<endl;
	int *ptr=&a;
	cout<<" Value at the memory location pointed by ptr:"<<*ptr<<endl;
	cout<<"Adress store in ptr "<<ptr<<endl;
	*ptr=100;
	cout<<" Updated value of a :"<<a<<endl;
	return 0;
}