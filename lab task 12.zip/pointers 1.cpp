#include<iostream>
using namespace std;
int main()
{
	 int a=60;
	 int *pa=&a;
	 cout<<a<<endl;
	 cout<<*pa<<endl;
	 cout<<pa<<endl;
	 cout<<&pa<<endl;
	 return 0;
}