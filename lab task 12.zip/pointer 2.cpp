#include<iostream>
using namespace std;
int main()
{
	 int a=80;
	 int *pa=&a;
	 int **dpa=&pa;
	 cout<<a<<endl;
	 cout<<*pa<<endl;
	 cout<<pa<<endl;
	 cout<<&pa<<endl;
	 cout<<**dpa<<endl;
	 return 0;
}