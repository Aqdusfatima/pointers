#include<iostream>
using namespace std;
int main()
{
	 int a=20;
	 int b=40;
	 cout<<"value of a= "<<a<<endl;
	 cout<<" value of b= "<<b<<endl;
	 int *temp=&a;
	  int v=*temp;
    	*temp=b;
    	b=v;
	cout<<"After swap: a= "<<a<<" b ="<<b<<endl;
	 return 0;
	 
}