# include<iostream>
using namespace std;
int main()
{
	int size;
	cout<<"enter the size of array"<<endl;
	cin>>size;
		int *arr=new int[size];
	for(int i=0;i<size;i++)
	{
		cin>>arr[i];
	}
	//pointer pointing to the first element of array
	cout<<"first element of array :"<<*arr<<endl;
	//printing the last element of array
	cout<<" last element is:" <<*(arr+size-1)<<endl;
	return 0;
}